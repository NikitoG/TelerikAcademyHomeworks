﻿//Problem 7. Print First and Last Name
//Create console application that prints your first and last name, each at a separate line.

using System;

class FirstAndLastName
{
    static void Main()
    {
        Console.WriteLine("Nikolay\nGeorgiev");
    }
}
