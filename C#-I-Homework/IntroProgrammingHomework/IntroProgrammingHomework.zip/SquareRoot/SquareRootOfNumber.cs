﻿//Problem 8. Square Root
//Create a console application that calculates and prints the square root of the number 12345.
//Find in Internet “how to calculate square root in C#”.

using System;

class SquareRootOfNumber
{
    static void Main()
    {
         Console.WriteLine("Square root of 12345 = " + Math.Sqrt(12345));
    }
}

